#!/opt/bin/python
import sys,re,os,random,math,numpy
from optparse import OptionParser
import logging
from pyfasta import Fasta

random.seed(1234)

global logfhd
def writelog():
    
    logfhd = open("log","w")

    logging.basicConfig(level=20,
                        format='%(levelname)-5s @ %(asctime)s: %(message)s ',
                        datefmt='%a, %d %b %Y %H:%M:%S',
                        stream=sys.stderr,
                        filemode="w"
                        )

    error   = logging.critical       
    warn    = logging.warning

    return logfhd

def info(a):
    logfhd = writelog()
    logging.info(a)
    logfhd.write(a+"\n")
    logfhd.flush()



def EM (READ,single_base):
    """ EM algorithm. input is a set of reads of an interval, output is m1 and m2 """
    m1 = random.random();m2 = random.random()  ## initial values of m1 and m2
    steps = 0 ## number of EM steps

    while True:
        nu1 = 0
        de1 = 0
        nu2 = 0
        de2 = 0
        num_read_m1 = 0
        num_read_m2 = 0 
        ave_read_m1=[]
        ave_read_m2=[]
        ave_meth_m1 = 0
        num_all_m1 = 0
        ave_meth_m2 = 0
        num_all_m2 = 0
        read_name_m1=[]
        read_name_m2=[]
        for key in READ:
            if "All" in READ[key]:
                p1 = (m1**READ[key]["Methy"])*((1-m1)**(READ[key]["All"] - READ[key]["Methy"]))
                p2 = (m2**READ[key]["Methy"])*((1-m2)**(READ[key]["All"] - READ[key]["Methy"]))
                Q1 = p1 / (p1 + p2)
                Q2 = p2 / (p1 + p2)
                nu1 += Q1 * READ[key]["Methy"]
                de1 += Q1 * READ[key]["All"]
                nu2 += Q2 * READ[key]["Methy"]
                de2 += Q2 * READ[key]["All"]
        if (de1*de2 ==0): ## invalid, return a random result
            return ("NA","NA","NA","NA","NA")
            break       
          
        m1_new = nu1 / de1
        m2_new = nu2 / de2
        
        if (abs(m1_new - m1) < 0.0001 and abs(m2_new - m2) < 0.0001) or steps > 100: ## num of steps <= 100
            for key in READ:
                if "All" in READ[key]:
                    p1 = (m1**READ[key]["Methy"])*((1-m1)**(READ[key]["All"] - READ[key]["Methy"]))
                    p2 = (m2**READ[key]["Methy"])*((1-m2)**(READ[key]["All"] - READ[key]["Methy"]))
                    if (p1 > p2):
                        num_read_m1 = num_read_m1 + 1
                        ave_read_m1.append(float(READ[key]["Methy"])/float(READ[key]["All"]))
                        ave_meth_m1 = ave_meth_m1 + float(READ[key]["Methy"])
                        num_all_m1 = num_all_m1 + float(READ[key]["All"])
                        read_name_m1.append(key)     #########      Recorded reads name
                        for i in range(len(single_base["start"])):
                            if str(int(single_base["start"][i])) in READ[key]["each_base"]:
                                single_base["m1"][i]+=READ[key]["each_base"][str(single_base["start"][i])]
                                single_base["m1_count"][i]+=1
#                           
                    else:
                        num_read_m2 = num_read_m2 + 1
                        ave_read_m2.append(float(READ[key]["Methy"])/float(READ[key]["All"]))
                        ave_meth_m2 = ave_meth_m2 + float(READ[key]["Methy"])
                        num_all_m2 = num_all_m2 + float(READ[key]["All"])
                        read_name_m2.append(key)   ########      Recorded reads name   
                        for i in range(len(single_base["start"])):
                            if str(single_base["start"][i]) in READ[key]["each_base"]:
                                single_base["m2"][i]+=READ[key]["each_base"][str(single_base["start"][i])]
                                single_base["m2_count"][i]+=1
                                
            if num_read_m1 == 0:
                SD_m1 = 0
                ave_meth_m1 = "NA"
            else:
                SD_m1 = numpy.std(ave_read_m1)
                ave_meth_m1 = ave_meth_m1/float(num_all_m1)
            if num_read_m2 == 0:
                SD_m2 = 0
                ave_meth_m1 = "NA"
            else:
                SD_m2 = numpy.std(ave_read_m2)
                ave_meth_m2 = ave_meth_m2/float(num_all_m2)
            SD_all = numpy.std(ave_read_m1+ave_read_m2)
            consist_score = SD_all*2-SD_m1-SD_m2
            ave_each_base_m1=0
            ave_each_base_m2=0
            for i in range(len(single_base["start"])): 
                if not single_base["m1_count"][i]==0:
                    ave_each_base_m1=single_base["m1"][i]/float(single_base["m1_count"][i])
                if not single_base["m2_count"][i]==0:
                    ave_each_base_m2=single_base["m2"][i]/float(single_base["m2_count"][i])
                if single_base["m1_count"][i]+single_base["m2_count"][i] > 0 :
                    single_base["diff"][i]= abs(ave_each_base_m1-ave_each_base_m2)
                    single_base["ave"][i] = (single_base["m1"][i]+single_base["m2"][i])/(float(single_base["m1_count"][i])+float(single_base["m2_count"][i]))
            return (m1,m2,num_read_m1,num_read_m2,abs(consist_score),single_base,read_name_m1,read_name_m2)            
            break        

        m1 = m1_new
        m2 = m2_new
        steps = steps + 1
        

    
def get_mixingRatio(input_file,output_file,bin_length,coverage_cutoff,genome):
    """ maximum likelihood by EM algorithm. input is datafile as all.sorted and bin-length, output is m1,m2 and P-value"""

    genome_file = genome
    f = Fasta(genome_file)

    IN = open(input_file,"r")
    out = open (output_file,"w")
    out1 = open (output_file+".single_base.bed","w")
    out.write("#chr\tstart\tend\tm1\tm2\tm1_read\tm2_read\talpha1\tave_methylation_level\tdiff\tcytosine_count_in_CG\n")
    out1.write("#chr\tstart\tend\tm1\tm2\tdiff\tave\n")

    # intialization
    CG_count_cutoff=5
    chr_current = "chr1"
    bin_start = 0
    READ = {}
    bin_reads = {}  ####### used for save each line
    bin_num =0

    for line in IN:
        tmp = line
        arr = line.strip().split("\t")      
        if len(arr) < 10 or arr[1]==256 or arr[1]==272 or len(arr[5])>4:
            continue
        readName = arr[0]
        chrN = arr[2]
        len_read = int(arr[5][:-1])
        start = int(arr[3])
        end = start + len_read
        read = arr[9]
        refseq = f[chrN][start-1:start-1+len_read].upper()
        if arr[1] == "16" or arr[1] == "0" or arr[1] == "113" or arr[1] == "145" or arr[1] == "147" or arr[1] == "153" or arr[1] == "177" or arr[1] == "81" or arr[1] == "83" or arr[1] == "89" or arr[1]  == "99" or arr[1]  == "97" or arr[1]  == "129" or arr[1]  == "137" or arr[1]  == "161" or arr[1]  == "163" or arr[1]  == "65" or arr[1]  == "73":
            strand = arr[1]
        elif len(arr)==13:
            strand = arr[12]

        if chrN != chr_current or start - bin_start > bin_length: ## it is a new bin

            # update the bin information
            CGcount = f[chrN][int(bin_start):int(bin_start+bin_length)].upper().count("CG")
            calculate_read_count_tmp = len([x for x,y in READ.items() if "All" in READ[x].keys()])      ######### calculate each bin read count that each read have more than CG
            if CGcount >=CG_count_cutoff: ## start a new bin
                if calculate_read_count_tmp > float(coverage_cutoff):
                    single_base={}
                    single_base["start"]=[]
                    single_base["diff"]=[]
                    single_base["m1"]=[]
                    single_base["m2"]=[]
                    single_base["m1_count"]=[]
                    single_base["m2_count"]=[]
                    single_base["ave"]=[]
                    bin_seq=f[chrN][int(bin_start-1):int(bin_start-1+bin_length)].upper()
                    for n in range(bin_length- 1):
                        if bin_seq[n:n+2] == "CG":
                            single_base["start"].append(int(bin_start+n)) # starts from 1  #####  float to int
                            single_base["diff"].append("NA")
                            single_base["ave"].append("NA")
                            single_base["m1"].append(0)
                            single_base["m2"].append(0)
                            single_base["m1_count"].append(0)
                            single_base["m2_count"].append(0)
                    (m1,m2,m1_read,m2_read,consist_score,single_base,read_name_m1,read_name_m2)=EM(READ,single_base)
                    if not m1=="NA":
                        meth=0
                        total=0

                        m1_read_tmp = m1_read
                        m2_read_tmp = m2_read
                        if m1_read > m2_read: # m1 for the minority
                            temp=m1_read
                            m1_read=m2_read
                            m2_read=temp
                            temp=m1
                            m1=m2
                            m2=temp
                            temp=read_name_m1
                            read_name_m1=read_name_m2
                            read_name_m2=temp
                        alpha1=m1_read/float(m1_read+m2_read)
                        for readName in READ.keys():
                            meth=meth+READ[readName]["original_Methy"]
                            total=total+READ[readName]["original_All"]
                        if total==0:
                            average="NA"
                        else:
                            average=float(meth)/float(total)
                            if average >= float(0.5):
                                bin_diff = abs(m1-m2)
                            elif average < float(0.5):
                                bin_diff = -abs(m1-m2)
                            dynamic = average-0.5
                        out.write ("%s\t%s\t%s\t%.3f\t%.3f\t%s\t%s\t%.2f\t%.3f\t%s\t%s\n" % (chr_current,int(bin_start),int(bin_start+bin_length),m1,m2,m1_read,m2_read,alpha1*100,average,bin_diff,CGcount))
                        for i in range(len(single_base["start"])):
                            if m1_read_tmp > m2_read_tmp:
                                out1.write("%s\t%s\t%s\t%s/%s\t%s/%s\t%s\t%s\n" % (chr_current,int(single_base["start"][i]-1),int(single_base["start"][i]+1),single_base["m2"][i],single_base["m2_count"][i],single_base["m1"][i],single_base["m1_count"][i],single_base["diff"][i],single_base["ave"][i]))
                            else:
                                out1.write("%s\t%s\t%s\t%s/%s\t%s/%s\t%s\t%s\n" % (chr_current,int(single_base["start"][i]-1),int(single_base["start"][i]+1),single_base["m1"][i],single_base["m1_count"][i],single_base["m2"][i],single_base["m2_count"][i],single_base["diff"][i],single_base["ave"][i]))
                        


            ## initialization
            READ = {}
            bin_num = bin_num+1
            bin_reads = {}
            bin_reads[readName]=[]
            bin_reads[readName].append(tmp.strip())
            chr_current = chrN
            bin_start = start/bin_length * bin_length
            #print "start a new bin",chrN,bin_start
            (n_me,n_all,each_base) = get_methyl(read,strand,refseq,start)
            if n_all >= 1 :
                READ[readName] = {}
                READ[readName]["original_Methy"] = n_me
                READ[readName]["original_All"] = n_all
                if n_all >= 2 :
                    READ[readName]["Methy"] = n_me
                    READ[readName]["All"] = n_all
                    READ[readName]["each_base"] = each_base

        else: ## an old bin just add reads
            if readName in bin_reads:
                bin_reads[readName].append(tmp.strip())
            else:
                bin_reads[readName]=[]
                bin_reads[readName].append(tmp.strip())
            (n_me,n_all,each_base) = get_methyl(read,strand,refseq,start)
            if n_all >= 1 :
                READ[readName] = {}
                READ[readName]["original_Methy"] = n_me
                READ[readName]["original_All"] = n_all
                if n_all >= 2 :
                    READ[readName]["Methy"] = n_me
                    READ[readName]["All"] = n_all
                    READ[readName]["each_base"] = each_base

    IN.close()
    out.close()


    
def get_methyl(read,strand,refseq,read_start):
        
    n_me = 0
    n_unme = 0
    each_base={}

    #------ Watson strand ------#
    
    if strand == "ZS:Z:++" or strand == "ZS:Z:+-" or strand == "0" or strand == "99" or strand == "97" or strand == "129" or strand == "137" or strand == "161" or strand == "163" or strand == "65" or strand == "73":
        for n in range(len(read) - 1):
            if refseq[n:n+2] == "CG":
                if read[n:n+2] == "CG":    
                    n_me += 1
                    each_base[str(read_start+n)]=1          #####   Record location methyltion information
                elif read[n:n+2] == "TG":
                    n_unme += 1
                    each_base[str(read_start+n)]=0
                else:
                    #print read[n:n+2]
                    pass


    #------ Crick strand ------#
    
    elif strand == "ZS:Z:-+" or strand == "ZS:Z:--" or strand == "16" or strand == "113" or strand == "145" or strand == "147" or strand == "153" or strand == "177" or strand == "81" or strand == "83" or strand == "89":
        for n in range(len(read) - 1):
            if refseq[n:n+2] == "CG":
                if read[n:n+2] == "CG":
                    n_me += 1
                    each_base[str(read_start+n)]=1
                elif read[n:n+2] == "CA":
                    n_unme += 1
                    each_base[str(read_start+n)]=0
                else:
                    #print read[n:n+2]
                    pass

    return(n_me,n_me + n_unme,each_base)



def merge(In,Out): ### Qian has updated this script
    
    """ merge bins into ASM region
    """
    info("Step 4: Merging adjacent significant bins ...")
    DMR_path = "/Program/program/AIMER/"
    DMR_file = "DMR_finder_v2.py"
    
    CMD_dmr = "python "+DMR_path+DMR_file+" -i "+In+" -o "+Out
    
    info("Run: %s" % CMD_dmr)
    os.system(CMD_dmr)
    
    return True


def main():
    usage = "usage: python %prog <-f filename> <-g ref_genome> [...]"
    description = "Select reads from two sam files. For example: python %prog -f input.bam -b 300 -c 20 -s 50"
    op = OptionParser(version="%prog 0.1",description=description,usage=usage,add_help_option=False)
    
    op.add_option("-h","--help",action="help",
                  help="Show this help message and exit.")
    op.add_option("-f","--filename",dest="filename",type="str",
                  help="The file name of mixing tissue, only accept bam file currently")
    op.add_option("-b","--BinLength",dest="BinLength",type="int",default="300",
                  help="Length of each bin, default is 300")
    op.add_option("-c","--coverage_cutoff",dest="coverage_cutoff",type="int",default="20",
                  help="Lowest coverage cutoff in each bin, default is 20")
    op.add_option("-g","--genome",dest="genome",type="str")
    op.add_option("-o","--output",dest="output",type="str",default = "bin.bed")
    (options,args) = op.parse_args()

    
    if not options.filename:
        op.print_help()
        sys.exit(1)

    filename = options.filename
    out = options.output
    bin_length = options.BinLength
    coverage_cutoff=options.coverage_cutoff
    genome = options.genome
    
   
    Input = filename

    get_mixingRatio(Input,out,bin_length,coverage_cutoff,genome)
    #os.system("python /Program/program/AIMER/DMR_finder.py -i "+out +" -o "+out+"_AMR.bed")

                  

               
if __name__ == "__main__":
    
    try:
        main()
    except KeyboardInterrupt:
        sys.stderr.write("User interrupt me, see you!\n")
        sys.exit(0)    

