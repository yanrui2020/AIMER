#!/opt/bin/python
#       version 1.2 add min_cg parameter ;after extending AMR ,at least one bin cg count must lager than min_cg
#       version 1.3 add proportion filter parameter 
#       changed gap length
import os,sys
from optparse import OptionParser

    #################       for bin extending
def Extending(AMR,bin_chr_pre,gap_len,diff_score_cutoff,bin_len,chr,OUT,min_cg,min_pro):
    valid_merged_score = 0
    merged_start = 0
    valid_merged_end = 0
    valid_merged_count = 0 
    valid_merged_pro = 0
    for i in range(len(AMR)):
        if AMR[i]["bin_score"] >=(diff_score_cutoff-0.05) and AMR[i]["skip"] =="false" : # each AMR starts from at least 0.8
            merged_start = AMR[i]["bin_start"]
            merged_end = AMR[i]["bin_start"]+bin_len        ####       the end after add bin 
            valid_merged_end = merged_end

            merged_pro = AMR[i]["bin_pro"]
            valid_merged_pro = merged_pro

            merged_score = AMR[i]["bin_score"]
            valid_merged_score = merged_score
            merged_count = 1
            valid_merged_count = merged_count
            gap_end = merged_end + gap_len          #### the end + gap 
            initial_gap_end = gap_end
            mean_score = diff_score_cutoff
            initial_mean_score = mean_score
            j = i+1
            while j<len(AMR) and AMR[j]["bin_start"] < gap_end and initial_mean_score >= diff_score_cutoff: # this start can still be involved in the last merged AMR calculation
                
                if AMR[j]["bin_score"] >= (diff_score_cutoff-0.05):
                    merged_score = merged_score + AMR[j]["bin_score"]
                    valid_merged_score = merged_score
                    
                    merged_end = AMR[j]["bin_start"] + bin_len 
                    valid_merged_end = merged_end
                    merged_pro = merged_pro + AMR[j]["bin_pro"]
                    valid_merged_pro = merged_pro

                    merged_count = merged_count + 1
                    valid_merged_count = merged_count
                    if (valid_merged_end - bin_len) < initial_gap_end:
                        initial_mean_score = initial_mean_score
                    else:
                        initial_mean_score = mean_score
                    gap_end = merged_end + gap_len
                    
                    mean_score = valid_merged_score/valid_merged_count
                else:           ########        null gap or score < score cutoff
                    merged_end = AMR[j]["bin_start"] +bin_len
                    merged_score = merged_score + AMR[j]["bin_score"]
                    merged_pro = merged_pro + AMR[j]["bin_pro"]
                    merged_count = merged_count + 1
                    mean_score = merged_score/merged_count

                    if (valid_merged_end - bin_len) < initial_gap_end:
                        initial_mean_score = initial_mean_score
                    else:
                        initial_mean_score = mean_score
                j = j+1   

            
            for n in range(int(i),int(j+1)):
                if n < len(AMR):
                    AMR[n]["skip"]="true"

            #######         at least one bin cg count must lager than min_cg
            cg_list = []
            for m in range(i,(i+valid_merged_count)):
                cg_num =  AMR[m]["bin_cg"]
                cg_list.append(cg_num)
            if max(cg_list) > min_cg:
                final_mean_score = valid_merged_score / valid_merged_count
                final_mean_pro = valid_merged_pro / valid_merged_count
                if final_mean_score >= diff_score_cutoff and final_mean_pro > min_pro:
                    OUT.write ("%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n" % (chr,merged_start,valid_merged_end,final_mean_score,valid_merged_end-merged_start,valid_merged_count,max(cg_list),final_mean_pro))

        else:
            pass


    print ("%s\t%s"%(chr, "merge done!"))
def main():
    
    usage = "usage: python %prog <-b BinLength> <-f filepath/name>"
    description = "This script merges bins result from MLEM algorithm to creat ASM AMRs."
    op = OptionParser(version="%prog 0.1",description=description,usage=usage,add_help_option=False)
    
    op.add_option("-h","--help",action="help",
                  help="Show this help message and exit.")
    op.add_option("-b","--input_bin",dest="input_bin",type="str",
                  help="input file, output of ML_EM.py ")
    op.add_option("-m","--proportion",dest="proportion",type="float",default="0.4",
                  help="proportion of min part,min(m1,m2)/(m1+m2),default=0.4")
    op.add_option("-s","--DiffScoreCutoff",dest="DiffScoreCutoff",type="float",default="0.7",
                  help="the cutoff of diff to extend a merged AMR,default=0.7")
    op.add_option("-g","--Gap",dest="Gap",type="int",default="700",
                  help="the gap length to extend a merged AMR,default=700")
    op.add_option("-d","--CG",dest="CG",type="int",default="10",
                  help="the cg density cutoff to extend a merged AMR,default=10")
    op.add_option("-o","--outputfilename",dest="outputfilename",type="str",
                  help="the output file name (with path), bed format")
    (options,args) = op.parse_args()

    
    if not options.input_bin:
        op.print_help()
        sys.exit(1)

    bin_file = options.input_bin

    min_pro = options.proportion        #### after extending AMR average proportion
    diff_score_cutoff=options.DiffScoreCutoff
    output=options.outputfilename
    gap_len =options.Gap
    min_cg = options.CG

    OUT = open (output,"w")
    n = 1
    ####################        bin file
    bin_chr_pre = "NA"
    bin_AMR = {}
    for eachline in open(bin_file,"r").readlines():
        if not eachline.startswith("#") :
            each = eachline.strip().split('\t')
            bin_chr = each[0]
            bin_start = each[1]
            bin_end = each[2]
            bin_score = each[9]
            bin_pro = float(each[7])/100
            bin_cg = int(each[10])
            if bin_pro > (min_pro-0.1):
                if bin_chr not in bin_AMR.keys():
                    if bin_chr_pre != "NA":
                        Extending(bin_AMR[bin_chr_pre],bin_chr_pre,gap_len,diff_score_cutoff,bin_len,bin_chr_pre,OUT,min_cg,min_pro)
                    bin_AMR[bin_chr] = []
                    bin_chr_pre = bin_chr
                    bin_len = int(bin_end) - int(bin_start)
                    bin_AMR[bin_chr].append({"bin_start":int(bin_start),"bin_len":bin_len,"bin_score":abs(float(bin_score)),"bin_pro":float(bin_pro),"bin_cg":bin_cg,"skip":"false"})
                else:
                    bin_AMR[bin_chr].append({"bin_start":int(bin_start),"bin_len":bin_len,"bin_score":abs(float(bin_score)),"bin_pro":float(bin_pro),"bin_cg":bin_cg,"skip":"false"})
    Extending(bin_AMR[bin_chr_pre],bin_chr_pre,gap_len,diff_score_cutoff,bin_len,bin_chr_pre,OUT,min_cg,min_pro)    
    OUT.close()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        sys.stderr.write("User interrupt me, see you!\n")
        sys.exit(0)

