import os,sys

chr={}
out=open(sys.argv[4],"w")
step=int(sys.argv[2])
col_num=int(sys.argv[3])
out.write("track type=wiggle_0 name=\""+sys.argv[1]+"_diff\" description=\"variableStep bin"+str(step)+" \"\n")
#out2.write("track type=wiggle_0 name=\""+sys.argv[1]+"_ave\" description=\"variableStep bin"+str(step)+" \"\n")
for eachline in open(sys.argv[1],"r").readlines():
    if not eachline.startswith("#"):
	#print eachline
        each=eachline.strip().split("\t")
        #if not chr.has_key(each[0]):
        if each[0] not in chr.keys():
            chr[each[0]]=1
            out.write("variableStep chrom=%s span=%s\n" % (each[0],step))
#	    out2.write("variableStep chrom=%s span=%s\n" % (each[0],step))
        if not each[col_num-1]=="NA":
            out.write("%s %s\n" % (str(int(each[1])+1),each[col_num-1]))
#	out2.write("%s %s\n" % (each[1],each[8]))
out.close()
#out2.close()

